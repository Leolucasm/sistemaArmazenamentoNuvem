/* DO NOT EDIT */
/* This file was generated from sharing_folders.babel, shared_links.babel */

/**
 * This namespace contains endpoints and data types for creating and managing
 * shared links and shared folders.
 *
 * <p> See {@link com.dropbox.core.v2.sharing.DbxUserSharingRequests} for a list
 * of possible requests for this namespace. </p>
 */
package com.dropbox.core.v2.sharing;
