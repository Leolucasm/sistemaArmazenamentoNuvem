/* DO NOT EDIT */
/* This file was generated from auth.babel */

/**
 * See {@link com.dropbox.core.v2.auth.DbxUserAuthRequests} for a list of
 * possible requests for this namespace.
 */
package com.dropbox.core.v2.auth;
