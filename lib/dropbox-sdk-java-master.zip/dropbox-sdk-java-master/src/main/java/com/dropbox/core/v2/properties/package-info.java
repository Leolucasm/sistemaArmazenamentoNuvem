/* DO NOT EDIT */
/* This file was generated from properties.babel */

/**
 * This namespace contains helper entities for property and property/template
 * endpoints.
 *
 * <p> See None for a list of possible requests for this namespace. </p>
 */
package com.dropbox.core.v2.properties;
