/* DO NOT EDIT */
/* This file was generated from files.babel */

/**
 * This namespace contains endpoints and data types for basic file operations.
 *
 * <p> See {@link com.dropbox.core.v2.files.DbxUserFilesRequests} for a list of
 * possible requests for this namespace. </p>
 */
package com.dropbox.core.v2.files;
